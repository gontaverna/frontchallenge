<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage taver
 * @since taver
 */ ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Rubik&display=swap");
    </style>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FrontEnd - Gonzalo Taverna</title>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css" />

    <script
      src="https://kit.fontawesome.com/239d2ac951.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <header>
      <section class="navbar-container">
        <div class="logo-desktop">
          <svg width="148" height="25" xmlns="http://www.w3.org/2000/svg">
            <g fill="none" fill-rule="evenodd">
              <path
                d="M37 6.299h5.227c.746 0 1.434.155 2.062.466.629.311 1.123.735 1.484 1.27s.542 1.12.542 1.754c0 .672-.165 1.254-.495 1.746-.33.491-.762.868-1.297 1.129v.15c.697.248 1.25.643 1.661 1.185.41.541.616 1.191.616 1.95 0 .735-.196 1.385-.588 1.951a3.817 3.817 0 0 1-1.587 1.307c-.665.305-1.403.457-2.212.457H37V6.299zm5.04 5.45c.548 0 .986-.152 1.316-.457.33-.305.495-.688.495-1.148 0-.448-.159-.824-.476-1.13-.318-.304-.738-.457-1.26-.457H39.52v3.192h2.52zm.28 5.619c.61 0 1.086-.159 1.428-.476.342-.317.513-.731.513-1.241 0-.51-.174-.927-.522-1.251-.349-.324-.847-.485-1.494-.485H39.52v3.453h2.8zm12.927 2.595c-1.307 0-2.492-.308-3.556-.924a6.711 6.711 0 0 1-2.511-2.53c-.61-1.07-.915-2.246-.915-3.528 0-1.281.305-2.457.915-3.528a6.711 6.711 0 0 1 2.51-2.529C52.756 6.308 53.94 6 55.248 6c1.306 0 2.492.308 3.556.924a6.711 6.711 0 0 1 2.51 2.53c.61 1.07.915 2.246.915 3.527 0 1.282-.305 2.458-.915 3.528a6.711 6.711 0 0 1-2.51 2.53c-1.064.616-2.25.924-3.556.924zm0-2.39a4.52 4.52 0 0 0 2.258-.578 4.177 4.177 0 0 0 1.615-1.624c.392-.697.588-1.494.588-2.39 0-.896-.196-1.692-.588-2.389a4.177 4.177 0 0 0-1.615-1.624 4.52 4.52 0 0 0-2.258-.579 4.47 4.47 0 0 0-2.25.579 4.195 4.195 0 0 0-1.605 1.624c-.392.697-.588 1.493-.588 2.39 0 .895.196 1.692.588 2.389a4.195 4.195 0 0 0 1.605 1.624 4.47 4.47 0 0 0 2.25.578zm15.353 2.39c-1.307 0-2.492-.308-3.556-.924a6.711 6.711 0 0 1-2.51-2.53c-.61-1.07-.915-2.246-.915-3.528 0-1.281.305-2.457.914-3.528a6.711 6.711 0 0 1 2.511-2.529C68.108 6.308 69.294 6 70.6 6c1.307 0 2.492.308 3.556.924a6.711 6.711 0 0 1 2.51 2.53c.61 1.07.915 2.246.915 3.527 0 1.282-.305 2.458-.914 3.528a6.711 6.711 0 0 1-2.511 2.53c-1.064.616-2.25.924-3.556.924zm0-2.39a4.52 4.52 0 0 0 2.259-.578 4.177 4.177 0 0 0 1.614-1.624c.392-.697.588-1.494.588-2.39 0-.896-.196-1.692-.588-2.389a4.177 4.177 0 0 0-1.614-1.624 4.52 4.52 0 0 0-2.259-.579 4.47 4.47 0 0 0-2.25.579 4.195 4.195 0 0 0-1.605 1.624c-.392.697-.588 1.493-.588 2.39 0 .895.196 1.692.588 2.389a4.195 4.195 0 0 0 1.606 1.624 4.47 4.47 0 0 0 2.249.578zM79.83 6.3h2.52v5.73h.15l4.89-5.73h3.043v.149L85.6 11.973l5.338 7.542v.149h-3.08l-3.994-5.693-1.512 1.773v3.92h-2.52V6.299zM93.779 6h3.248l3.546 9.39h.15L104.268 6h3.267v13.365h-2.501v-6.589l.15-2.221h-.15l-3.398 8.81h-1.96l-3.416-8.81h-.149l.15 2.221v6.59h-2.483V6zm20.8 0h2.894l5.021 13.365h-2.781l-1.12-3.192h-5.115l-1.12 3.192h-2.781L114.579 6zm3.193 7.859l-1.176-3.36-.486-1.606h-.149l-.485 1.606-1.195 3.36h3.49zM124.553 6h4.872c.871 0 1.646.18 2.324.541.678.361 1.204.862 1.577 1.503.374.64.56 1.366.56 2.175 0 .858-.27 1.62-.812 2.286a4.617 4.617 0 0 1-2.044 1.447l-.018.13 3.584 5.134v.15h-2.894l-3.453-5.022h-1.176v5.021h-2.52V6zm4.853 6.03c.573 0 1.04-.175 1.4-.523.361-.349.542-.79.542-1.326 0-.51-.172-.945-.514-1.306-.342-.361-.806-.542-1.39-.542h-2.371v3.696h2.333zm7.23-6.03h2.52v5.73h.15l4.89-5.73h3.043v.15l-4.835 5.525 5.34 7.541v.15h-3.08l-3.996-5.694-1.512 1.773v3.92h-2.52V6z"
                fill="#242A45"
                fill-rule="nonzero"
              />
              <g>
                <circle fill="#5267DF" cx="12.5" cy="12.5" r="12.5" />
                <path
                  d="M9 9v10l3.54-3.44L16.078 19V9a2 2 0 0 0-2-2H11a2 2 0 0 0-2 2z"
                  fill="#FFF"
                />
              </g>
            </g>
          </svg>
        </div>
        <div onclick="updateHeader()" class="menu-button">
          <img src="<?php echo get_template_directory_uri(); ?>/images/icon-hamburger.svg" alt="hamburger" />
        </div>
        <nav class="menu-container">
          <article class="menu-mobile">
            <div class="logo-mobile">
              <div class="logo">
                <svg width="148" height="25" xmlns="http://www.w3.org/2000/svg">
                  <g fill="none" fill-rule="evenodd">
                    <path
                      d="M37 6.299h5.227c.746 0 1.434.155 2.062.466.629.311 1.123.735 1.484 1.27s.542 1.12.542 1.754c0 .672-.165 1.254-.495 1.746-.33.491-.762.868-1.297 1.129v.15c.697.248 1.25.643 1.661 1.185.41.541.616 1.191.616 1.95 0 .735-.196 1.385-.588 1.951a3.817 3.817 0 0 1-1.587 1.307c-.665.305-1.403.457-2.212.457H37V6.299zm5.04 5.45c.548 0 .986-.152 1.316-.457.33-.305.495-.688.495-1.148 0-.448-.159-.824-.476-1.13-.318-.304-.738-.457-1.26-.457H39.52v3.192h2.52zm.28 5.619c.61 0 1.086-.159 1.428-.476.342-.317.513-.731.513-1.241 0-.51-.174-.927-.522-1.251-.349-.324-.847-.485-1.494-.485H39.52v3.453h2.8zm12.927 2.595c-1.307 0-2.492-.308-3.556-.924a6.711 6.711 0 0 1-2.511-2.53c-.61-1.07-.915-2.246-.915-3.528 0-1.281.305-2.457.915-3.528a6.711 6.711 0 0 1 2.51-2.529C52.756 6.308 53.94 6 55.248 6c1.306 0 2.492.308 3.556.924a6.711 6.711 0 0 1 2.51 2.53c.61 1.07.915 2.246.915 3.527 0 1.282-.305 2.458-.915 3.528a6.711 6.711 0 0 1-2.51 2.53c-1.064.616-2.25.924-3.556.924zm0-2.39a4.52 4.52 0 0 0 2.258-.578 4.177 4.177 0 0 0 1.615-1.624c.392-.697.588-1.494.588-2.39 0-.896-.196-1.692-.588-2.389a4.177 4.177 0 0 0-1.615-1.624 4.52 4.52 0 0 0-2.258-.579 4.47 4.47 0 0 0-2.25.579 4.195 4.195 0 0 0-1.605 1.624c-.392.697-.588 1.493-.588 2.39 0 .895.196 1.692.588 2.389a4.195 4.195 0 0 0 1.605 1.624 4.47 4.47 0 0 0 2.25.578zm15.353 2.39c-1.307 0-2.492-.308-3.556-.924a6.711 6.711 0 0 1-2.51-2.53c-.61-1.07-.915-2.246-.915-3.528 0-1.281.305-2.457.914-3.528a6.711 6.711 0 0 1 2.511-2.529C68.108 6.308 69.294 6 70.6 6c1.307 0 2.492.308 3.556.924a6.711 6.711 0 0 1 2.51 2.53c.61 1.07.915 2.246.915 3.527 0 1.282-.305 2.458-.914 3.528a6.711 6.711 0 0 1-2.511 2.53c-1.064.616-2.25.924-3.556.924zm0-2.39a4.52 4.52 0 0 0 2.259-.578 4.177 4.177 0 0 0 1.614-1.624c.392-.697.588-1.494.588-2.39 0-.896-.196-1.692-.588-2.389a4.177 4.177 0 0 0-1.614-1.624 4.52 4.52 0 0 0-2.259-.579 4.47 4.47 0 0 0-2.25.579 4.195 4.195 0 0 0-1.605 1.624c-.392.697-.588 1.493-.588 2.39 0 .895.196 1.692.588 2.389a4.195 4.195 0 0 0 1.606 1.624 4.47 4.47 0 0 0 2.249.578zM79.83 6.3h2.52v5.73h.15l4.89-5.73h3.043v.149L85.6 11.973l5.338 7.542v.149h-3.08l-3.994-5.693-1.512 1.773v3.92h-2.52V6.299zM93.779 6h3.248l3.546 9.39h.15L104.268 6h3.267v13.365h-2.501v-6.589l.15-2.221h-.15l-3.398 8.81h-1.96l-3.416-8.81h-.149l.15 2.221v6.59h-2.483V6zm20.8 0h2.894l5.021 13.365h-2.781l-1.12-3.192h-5.115l-1.12 3.192h-2.781L114.579 6zm3.193 7.859l-1.176-3.36-.486-1.606h-.149l-.485 1.606-1.195 3.36h3.49zM124.553 6h4.872c.871 0 1.646.18 2.324.541.678.361 1.204.862 1.577 1.503.374.64.56 1.366.56 2.175 0 .858-.27 1.62-.812 2.286a4.617 4.617 0 0 1-2.044 1.447l-.018.13 3.584 5.134v.15h-2.894l-3.453-5.022h-1.176v5.021h-2.52V6zm4.853 6.03c.573 0 1.04-.175 1.4-.523.361-.349.542-.79.542-1.326 0-.51-.172-.945-.514-1.306-.342-.361-.806-.542-1.39-.542h-2.371v3.696h2.333zm7.23-6.03h2.52v5.73h.15l4.89-5.73h3.043v.15l-4.835 5.525 5.34 7.541v.15h-3.08l-3.996-5.694-1.512 1.773v3.92h-2.52V6z"
                      fill="#FFF"
                      fill-rule="nonzero"
                    />
                    <g>
                      <circle fill="#FFF" cx="12.5" cy="12.5" r="12.5" />
                      <path
                        d="M9 9v10l3.54-3.44L16.078 19V9a2 2 0 0 0-2-2H11a2 2 0 0 0-2 2z"
                        fill="hsl(229, 31%, 21%)"
                      />
                    </g>
                  </g>
                </svg>
              </div>
              <span onclick="updateHeader()" class="btn-close">x</span>
            </div>
            <ul>
              <li><a href="#">FEATURES</a></li>
              <li><a href="#">PRICING</a></li>
              <li><a href="#">CONTACT</a></li>
              <li><a class="button danger" href="#">LOGIN</a></li>
            </ul>
          </article>

          <div class="logo-mobile">
            <div class="logo">
              <img src="<?php echo get_template_directory_uri(); ?>/images/icon-facebook.svg" alt="facebook" />
            </div>
            <div class="logo">
              <img src="<?php echo get_template_directory_uri(); ?>/images/icon-twitter.svg" alt="twitter" />
            </div>
          </div>
        </nav>
      </section>
    </header>
    <main>
      <section class="hero">
        <article class="hero-container">
          <h1>
            A Simple Bookmark <br />
            <br class="br-mobile" />
            Manager
          </h1>
          <p>
            A clean and simple interface to organize <br class="br-mobile" />
            your favorite <br />
            websites. Open a new <br class="br-mobile" />
            browser tab and see your sites load <br class="br-mobile" />
            <br />
            instantly. Try it for free.
          </p>
          <div class="btn-container">
            <a href="#" class="button info">Get in on Chrome</a>
            <a href="#" class="button grey">Get in on Firefox</a>
          </div>
        </article>

        <div class="img-container">
          <img class="hero-img" src="<?php echo get_template_directory_uri(); ?>/images/illustration-hero.svg" alt="hero" />
        </div>
      </section>
      <section class="features">
        <article class="hero-container">
          <h1>Features</h1>
          <p>
            Our aim is to make it quick and easy for you
            <br class="br-mobile" />
            to acces to your
            <br />
            favourite websites. Your <br class="br-mobile" />
            bookmarks sync between your devices <br />
            so <br class="br-mobile" />
            you can access them on the go.
          </p>
          <div class="tabs-container">
            <ul class="tabs">
              <li>
                <a
                  class="tab-title tab1 tab-selected"
                  onclick="updateTab('tab1')"
                  >Simple Bookmarking</a
                >
              </li>
              <li>
                <a class="tab-title tab2" onclick="updateTab('tab2')"
                  >Speedy Searching</a
                >
              </li>
              <li>
                <a class="tab-title tab3" onclick="updateTab('tab3')"
                  >Easy Sharing</a
                >
              </li>
            </ul>
            <div class="tabs-content">
              <div id="tab1" class="tab">
                <div class="img-container-tab">
                  <img
                    class="hero-img"
                    src="<?php echo get_template_directory_uri(); ?>/images/illustration-features-tab-1.svg"
                    alt="tab1"
                  />
                </div>
                <div class="hero-container">
                  <h1>Bookmark in one click</h1>
                  <p>
                    Organize your boorkmaks however you like.
                    <br class="br-mobile" />
                    Our <br />
                    simple drag-and-drop interface gives
                    <br class="br-mobile" />
                    you complete <br />
                    ontrol over how you manage <br class="br-mobile" />
                    your favorite sites.
                  </p>
                  <div class="btn-container">
                    <a href="#" class="button info">More info</a>
                  </div>
                </div>
              </div>

              <div id="tab2" class="tab" style="display: none">
                <div class="img-container-tab">
                  <img
                    class="hero-img"
                    src="<?php echo get_template_directory_uri(); ?>/images/illustration-features-tab-2.svg"
                    alt="tab2"
                  />
                </div>

                <div class="hero-container">
                  <h1>Intelligent search</h1>
                  <p>
                    Our powerful search feature will help you
                    <br class="br-mobile" />
                    find saved <br />
                    sites in no time at all. No need to <br class="br-mobile" />
                    trawl through all of
                    <br />
                    your bookmarks.
                  </p>
                  <div class="btn-container">
                    <a href="#" class="button info">More info</a>
                  </div>
                </div>
              </div>

              <div id="tab3" class="tab" style="display: none">
                <div class="img-container-tab">
                  <img
                    class="hero-img"
                    src="<?php echo get_template_directory_uri(); ?>/images/illustration-features-tab-3.svg"
                    alt="tab3"
                  />
                </div>

                <div class="hero-container">
                  <h1>Share your bookmarks</h1>
                  <p>
                    Easily share your bookmarks and <br class="br-mobile" />
                    collecions with <br />
                    others. Create a shareable link<br class="br-mobile" />
                    that you can send at <br />
                    the click <br class="br-mobile" />
                    of a button.
                  </p>
                  <div class="btn-container">
                    <a href="#" class="button info">More info</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </article>
      </section>
      <section class="extensions">
        <article class="hero-container">
          <h1>Download the extensions</h1>
          <p>
            We've got more browsers in the pipeline.<br class="br-mobile" />
            Please do let us know if
            <br />
            you've got a <br class="br-mobile" />
            favourite you'd like us to priorize.
          </p>
          <div class="cards">
            <article class="card">
              <div class="card-content">
                <img src="<?php echo get_template_directory_uri(); ?>/images/logo-chrome.svg" alt="chrome" />
                <h2>Add to Chrome</h2>
                <p>Minimum version 62</p>
                <img class="dots" src="<?php echo get_template_directory_uri(); ?>/images/bg-dots.svg" alt="dots" />
              </div>
              <a class="button info" href="#">Add & Install Extension</a>
            </article>
            <article class="card mt-40">
              <div class="card-content">
                <img src="<?php echo get_template_directory_uri(); ?>/images/logo-firefox.svg" alt="firefox" />
                <h2>Add to Firefox</h2>
                <p>Minimum version 55</p>
                <img class="dots" src="<?php echo get_template_directory_uri(); ?>/images/bg-dots.svg" alt="dots" />
              </div>

              <a class="button info" href="#">Add & Install Extension</a>
            </article>
            <article class="card mt-80">
              <div class="card-content">
                <img src="<?php echo get_template_directory_uri(); ?>/images/logo-opera.svg" alt="opera" />
                <h2>Add to Opera</h2>
                <p>Minimum version 46</p>
                <img class="dots" src="<?php echo get_template_directory_uri(); ?>/images/bg-dots.svg" alt="dots" />
              </div>

              <a class="button info" href="#">Add & Install Extension</a>
            </article>
          </div>
        </article>
      </section>
      <section class="faqs">
        <article class="hero-container">
          <h1>Frequently Asked Questions</h1>
          <p>
            Here are some of our FAQs. If you have any<br class="br-mobile" />
            other questions <br />
            you'd like answered please <br class="br-mobile" />
            feel free to email us.
          </p>
          <div class="faq-accordion">
            <div class="faq-card">
              <div class="faq-card-header">
                <h3 class="faq-card-title">What is a bookmark?</h3>
                <span class="faq-toggle-icon"
                  ><i class="fas fa-chevron-down"></i
                ></span>
              </div>
              <div class="faq-card-body">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Egestas tellus rutrum tellus pellentesque eu tincidunt tortor
                  aliquam.
                </p>
              </div>
            </div>
            <div class="faq-card">
              <div class="faq-card-header">
                <h3 class="faq-card-title">How can I request a new browser?</h3>
                <span class="faq-toggle-icon"
                  ><i class="fas fa-chevron-down"></i
                ></span>
              </div>
              <div class="faq-card-body">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Egestas tellus rutrum tellus pellentesque eu tincidunt tortor
                  aliquam.
                </p>
              </div>
            </div>
            <div class="faq-card">
              <div class="faq-card-header">
                <h3 class="faq-card-title">Is there a mobile app?</h3>
                <span class="faq-toggle-icon"
                  ><i class="fas fa-chevron-down"></i
                ></span>
              </div>
              <div class="faq-card-body">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Egestas tellus rutrum tellus pellentesque eu tincidunt tortor
                  aliquam.
                </p>
              </div>
            </div>
            <div class="faq-card">
              <div class="faq-card-header">
                <h3 class="faq-card-title">
                  What abour other Chromium browsers?
                </h3>
                <span class="faq-toggle-icon"
                  ><i class="fas fa-chevron-down"></i
                ></span>
              </div>
              <div class="faq-card-body">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Egestas tellus rutrum tellus pellentesque eu tincidunt tortor
                  aliquam.
                </p>
              </div>
            </div>
          </div>
          <a class="button info">More info </a>
        </article>
      </section>
      <section class="contact">
        <article class="hero-container">
          <h3>35,000 + ALREADY JOINED</h3>
          <h1>
            Stay up-to-date with what <br class="br-mobile" />
            <br />
            we're doing
          </h1>
          <article class="contact-container">
            <form>
              <input
                type="email"
                placeholder="Enter your email address"
                name="email"
                id="email"
                required
                oninvalid="this.setCustomValidity('Whoops, make sure its an email')"
              />
              <input type="submit" class="button danger" value="Contact Us" />
            </form>
          </article>
        </article>
      </section>
    </main>
    <footer>
      <section class="navbar-container">
        <article class="menu-container">
          <div class="logo">
            <svg width="148" height="25" xmlns="http://www.w3.org/2000/svg">
              <g fill="none" fill-rule="evenodd">
                <path
                  d="M37 6.299h5.227c.746 0 1.434.155 2.062.466.629.311 1.123.735 1.484 1.27s.542 1.12.542 1.754c0 .672-.165 1.254-.495 1.746-.33.491-.762.868-1.297 1.129v.15c.697.248 1.25.643 1.661 1.185.41.541.616 1.191.616 1.95 0 .735-.196 1.385-.588 1.951a3.817 3.817 0 0 1-1.587 1.307c-.665.305-1.403.457-2.212.457H37V6.299zm5.04 5.45c.548 0 .986-.152 1.316-.457.33-.305.495-.688.495-1.148 0-.448-.159-.824-.476-1.13-.318-.304-.738-.457-1.26-.457H39.52v3.192h2.52zm.28 5.619c.61 0 1.086-.159 1.428-.476.342-.317.513-.731.513-1.241 0-.51-.174-.927-.522-1.251-.349-.324-.847-.485-1.494-.485H39.52v3.453h2.8zm12.927 2.595c-1.307 0-2.492-.308-3.556-.924a6.711 6.711 0 0 1-2.511-2.53c-.61-1.07-.915-2.246-.915-3.528 0-1.281.305-2.457.915-3.528a6.711 6.711 0 0 1 2.51-2.529C52.756 6.308 53.94 6 55.248 6c1.306 0 2.492.308 3.556.924a6.711 6.711 0 0 1 2.51 2.53c.61 1.07.915 2.246.915 3.527 0 1.282-.305 2.458-.915 3.528a6.711 6.711 0 0 1-2.51 2.53c-1.064.616-2.25.924-3.556.924zm0-2.39a4.52 4.52 0 0 0 2.258-.578 4.177 4.177 0 0 0 1.615-1.624c.392-.697.588-1.494.588-2.39 0-.896-.196-1.692-.588-2.389a4.177 4.177 0 0 0-1.615-1.624 4.52 4.52 0 0 0-2.258-.579 4.47 4.47 0 0 0-2.25.579 4.195 4.195 0 0 0-1.605 1.624c-.392.697-.588 1.493-.588 2.39 0 .895.196 1.692.588 2.389a4.195 4.195 0 0 0 1.605 1.624 4.47 4.47 0 0 0 2.25.578zm15.353 2.39c-1.307 0-2.492-.308-3.556-.924a6.711 6.711 0 0 1-2.51-2.53c-.61-1.07-.915-2.246-.915-3.528 0-1.281.305-2.457.914-3.528a6.711 6.711 0 0 1 2.511-2.529C68.108 6.308 69.294 6 70.6 6c1.307 0 2.492.308 3.556.924a6.711 6.711 0 0 1 2.51 2.53c.61 1.07.915 2.246.915 3.527 0 1.282-.305 2.458-.914 3.528a6.711 6.711 0 0 1-2.511 2.53c-1.064.616-2.25.924-3.556.924zm0-2.39a4.52 4.52 0 0 0 2.259-.578 4.177 4.177 0 0 0 1.614-1.624c.392-.697.588-1.494.588-2.39 0-.896-.196-1.692-.588-2.389a4.177 4.177 0 0 0-1.614-1.624 4.52 4.52 0 0 0-2.259-.579 4.47 4.47 0 0 0-2.25.579 4.195 4.195 0 0 0-1.605 1.624c-.392.697-.588 1.493-.588 2.39 0 .895.196 1.692.588 2.389a4.195 4.195 0 0 0 1.606 1.624 4.47 4.47 0 0 0 2.249.578zM79.83 6.3h2.52v5.73h.15l4.89-5.73h3.043v.149L85.6 11.973l5.338 7.542v.149h-3.08l-3.994-5.693-1.512 1.773v3.92h-2.52V6.299zM93.779 6h3.248l3.546 9.39h.15L104.268 6h3.267v13.365h-2.501v-6.589l.15-2.221h-.15l-3.398 8.81h-1.96l-3.416-8.81h-.149l.15 2.221v6.59h-2.483V6zm20.8 0h2.894l5.021 13.365h-2.781l-1.12-3.192h-5.115l-1.12 3.192h-2.781L114.579 6zm3.193 7.859l-1.176-3.36-.486-1.606h-.149l-.485 1.606-1.195 3.36h3.49zM124.553 6h4.872c.871 0 1.646.18 2.324.541.678.361 1.204.862 1.577 1.503.374.64.56 1.366.56 2.175 0 .858-.27 1.62-.812 2.286a4.617 4.617 0 0 1-2.044 1.447l-.018.13 3.584 5.134v.15h-2.894l-3.453-5.022h-1.176v5.021h-2.52V6zm4.853 6.03c.573 0 1.04-.175 1.4-.523.361-.349.542-.79.542-1.326 0-.51-.172-.945-.514-1.306-.342-.361-.806-.542-1.39-.542h-2.371v3.696h2.333zm7.23-6.03h2.52v5.73h.15l4.89-5.73h3.043v.15l-4.835 5.525 5.34 7.541v.15h-3.08l-3.996-5.694-1.512 1.773v3.92h-2.52V6z"
                  fill="#FFF"
                  fill-rule="nonzero"
                />
                <g>
                  <circle fill="#5267DF" cx="12.5" cy="12.5" r="12.5" />
                  <path
                    d="M9 9v10l3.54-3.44L16.078 19V9a2 2 0 0 0-2-2H11a2 2 0 0 0-2 2z"
                    fill="#FFF"
                  />
                </g>
              </g>
            </svg>
          </div>

          <nav>
            <ul>
              <li><a href="#">FEATURES</a></li>
              <li><a href="#">PRICING</a></li>
              <li><a href="#">CONTACT</a></li>
            </ul>
          </nav>
        </article>

        <article class="footer-social">
          <div class="logo">
            <i class="fa-brands fa-square-facebook"></i>
          </div>
          <div class="logo">
            <i class="fa fa-twitter"></i>
          </div>
        </article>
      </section>
    </footer>
  </body>

  <script src="js/index.js"></script>
</html>
